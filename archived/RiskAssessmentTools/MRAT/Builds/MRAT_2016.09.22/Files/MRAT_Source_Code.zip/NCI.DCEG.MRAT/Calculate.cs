using System;

namespace NCI.DCEG.MRAT
{
    /// <summary>
    /// Calculate Melanoma Risk.
    /// </summary>
    public static class Calculate
    {
        #region Methods

        /// <summary>
        /// Calculate Risk.
        /// </summary>
        /// <param name="region">Region.</param>
        /// <param name="sex">Sex</param>
        /// <param name="race">Race</param>
        /// <param name="age">Age</param>
        /// <param name="sunburn">Sunburnt</param>
        /// <param name="complexion">Skin Complexion</param>
        /// <param name="large_moles">Presence of large moles.</param>
        /// <param name="small_moles_males">Presence of small moles</param>
        /// <param name="small_moles_females">Presence of small moles</param>
        /// <param name="frekcling">Freckling</param>
        /// <param name="solar_damage">Any solar damage.</param>
        /// <param name="tanning">Taning.</param>
        /// <returns></returns>
        public static double CalculateRisk(
            int region, int sex, int race, int age, 
            int sunburn, int complexion, int large_moles, 
            int small_moles_males, int small_moles_females,
            int freckling, int solar_damage,
            int tanning)
        {
            double result = 0.0;
            if (sex == Constants.MALE)
                result = Utils.processMale(region, sex, race, age, sunburn, 
                    complexion, large_moles, small_moles_males, freckling, solar_damage);
            else if (sex == Constants.FEMALE)
                result = Utils.processFemale(region, sex, race, age, complexion, tanning, 
                    small_moles_females, freckling);
            return result;
        }

        #endregion Methods
    }
}
