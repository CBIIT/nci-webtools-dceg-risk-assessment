using System;
using System.Collections;

namespace NCI.DCEG.MRAT
{
    /// <summary>
    /// Helper class.
    /// </summary>
    internal static class Utils
    {
        #region Methods

        /// <summary>
        /// Process male statistics and return risk.
        /// </summary>
        /// <param name="region">Region.</param>
        /// <param name="sex">Sex</param>
        /// <param name="race">Race</param>
        /// <param name="age">Age</param>
        /// <param name="sunburn">Sunburnt</param>
        /// <param name="complexion">Skin Complexion</param>
        /// <param name="large_moles">Presence of large moles.</param>
        /// <param name="small_moles_males">Presence of small moles</param>
        /// <param name="frekcling">Freckling</param>
        /// <param name="solar_damage">Any solar damage.</param>
        /// <returns>Risk</returns>
        public static double processMale(
            int region, int sex, int race, int age, 
            int sunburn, int complexion, int large_moles, 
            int small_moles_males, int frekcling, int solar_damage)
        {
            ArrayList phenoVals = new ArrayList();
            phenoVals.Add(Constants.malePhenoBlisterBurn[sunburn]);
            phenoVals.Add(Constants.malePhenoFairComplexion[complexion]);
            phenoVals.Add(Constants.malePhenoLargeMoles[large_moles]);
            phenoVals.Add(Constants.malePhenoSmallMoles[small_moles_males]);
            phenoVals.Add(Constants.malePhenoMildFreckling[frekcling]);
            phenoVals.Add(Constants.malePhenoSolarDamage[solar_damage]);
            double risk = calculateRisk(sex, age, region, phenoVals);
            return risk;
        }

        /// <summary>
        /// Process female statistics and return risk.
        /// </summary>
        /// <param name="region">Region.</param>
        /// <param name="sex">Sex.</param>
        /// <param name="race">Race.</param>
        /// <param name="age">Age.</param>
        /// <param name="complexion">Skin Complexion.</param>
        /// <param name="tanning">Existence of taning.</param>
        /// <param name="small_moles_females">Presence of small moles.</param>
        /// <param name="frekcling">Freckling.</param>
        /// <returns>Risk.</returns>
        public static double processFemale(
            int region, int sex, int race, int age, 
            int complexion, int tanning, 
            int small_moles_females, int frekcling)
        {
            ArrayList phenoVals = new ArrayList();
            phenoVals.Add(Constants.femalePhenoFairComplexion[complexion]);
            phenoVals.Add(Constants.femalePhenoLightOrNoTan[tanning]);
            phenoVals.Add(Constants.femalePhenoSmallMoles[small_moles_females]);
            phenoVals.Add(Constants.femalePhenoMildFreckling[frekcling]);
            double risk = calculateRisk(sex, age, region, phenoVals);
            return risk;
        }

        /// <summary>
        /// Calculate risk.
        /// </summary>
        /// <param name="sex">Sex.</param>
        /// <param name="age">Age.</param>
        /// <param name="region">Region.</param>
        /// <param name="phenoValuesRef">Pheno values.</param>
        /// <returns>Risk.</returns>
        private static double calculateRisk(int sex, int age, int region, ArrayList phenoValuesRef)
        {
            int ageIndex = getAgeIndex(age);
            int t1 = getT1(ageIndex);
            int t2 = t1 + 5; //# adding 5 gets us the next age interval
            double r = multiplyArray(phenoValuesRef);
            double h11 = (1 - getAttributableRisk(sex)) * getIncidence(sex, ageIndex, region); //#values are per 100,000
            double h21 = getNonMelanomaMortality(sex, ageIndex);
            double risk = 0.0;
            risk = (h11 * r / ((h11 * r) + h21) * (1 - Math.Exp((-1 * (t2 - age)) * ((h11 * r) + h21))));
            if (age % 5 != 0)
            {
                double h12 = (1 - getAttributableRisk(sex)) * getIncidence(sex, ageIndex + 1, region); //#values are per 100,000
                double h22 = getNonMelanomaMortality(sex, ageIndex + 1);
                risk += (((h12 * r) / ((h12 * r) + h22)) *
                         Math.Exp(-1 * (t2 - age) * ((h11 * r) + h21)) *
                         (1 - Math.Exp(-1 * (age + 5 - t2) * ((h12 * r) + h22))));
            }

            risk = risk * 100; 
            return risk;
        }

        /// <summary>
        /// Get sex based risk from constants table.
        /// </summary>
        /// <param name="sex">Sex.</param>
        /// <returns>Risk.</returns>
        private static double getAttributableRisk(int sex)
        {
            double attributableRisk = Convert.ToDouble(Constants.attributableRisk[sex]);
            return attributableRisk;
        }

        /// <summary>
        /// Get the morality value.
        /// </summary>
        /// <param name="sex">Sex.</param>
        /// <param name="ageIndex">Age Index.</param>
        /// <returns>Risk.</returns>
        private static double getNonMelanomaMortality(int sex, int ageIndex)
        {
            double mortality = 0.0;
            if (sex == Constants.MALE)
                mortality = Constants.male_mort[ageIndex];
            else if (sex == Constants.FEMALE)
                mortality = Constants.female_mort[ageIndex];
            else
                throw new Exception("Invalid main parameter: getNonMelanomaMortality");
            return mortality / 100000;//# mortality rates are per 100,000 (See table 1 in the manuscript)
        }

        /// <summary>
        /// Get incidence based on sex, age index and location.
        /// </summary>
        /// <param name="sex">Sex.</param>
        /// <param name="ageIndex">Age Index.</param>
        /// <param name="region">Region.</param>
        /// <returns>Risk.</returns>
        public static double getIncidence(int sex, int ageIndex, int region)
        {
            double incidence = 0.0;
            if (sex == Constants.MALE)
                incidence = Constants.male_incidence[ageIndex, (Constants.REGION_MAX - region)];
            else if (sex == Constants.FEMALE)
                incidence = Constants.female_incidence[ageIndex, (Constants.REGION_MAX - region)];
            else
                throw new Exception("Invalid parameter: getIndicence");
            return incidence / 100000; //# incidence rates are per 100,000 (See table 1 in the manuscript)
        }

        /// <summary>
        /// Get the age index from age.
        /// </summary>
        /// <param name="age">Age.</param>
        /// <returns>Age Index.</returns>
        private static int getAgeIndex(int age)
        {
            return (int)((age - 20) / 5);
        }

        /// <summary>
        /// Get T1 value.
        /// </summary>
        /// <param name="ageIndex">Age Index.</param>
        /// <returns>T1 Value.</returns>
        private static int getT1(int ageIndex)
        {
            return ((ageIndex * 5) + 20);
        }

        /// <summary>
        /// Multiple pheno values.
        /// </summary>
        /// <param name="phenoValuesRef">Pheno values.</param>
        /// <returns>Risk.</returns>
        private static double multiplyArray(ArrayList phenoValuesRef)
        {
            double r = 1;
            foreach (object val in phenoValuesRef)
            {
                double retval = 0;
                if (val != null)
                {
                    if (!double.TryParse(val.ToString(), out retval))
                        throw new Exception("Non numeric parameter: multiplyArray");
                    r = r * retval;
                }
            }
            return r;
        }
    }

        #endregion Methods
}