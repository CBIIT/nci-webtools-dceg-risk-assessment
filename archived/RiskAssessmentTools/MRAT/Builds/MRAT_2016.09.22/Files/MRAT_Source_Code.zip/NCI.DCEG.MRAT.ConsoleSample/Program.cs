using System;
using NCI.DCEG.MRAT;

namespace NCI.DCEG.MRAT.ConsoleSample
{
    /// <summary>
    /// Console application.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main entry point.
        /// </summary>
        /// <param name="args">Cmd-line args.</param>
        static void Main(string[] args)
        {
            Console.WriteLine("The following assessment is a percentage value of risk of contracting melanoma" +
                              " for a non-hispanic white male of 32 in central US, with medium skin complexion," +
                              " little to no large or small moles," +
                              " solar damage, or freckling on the back skin tissue." + Environment.NewLine);
            double risk = Calculate.CalculateRisk(1, 1, 1, 32, 1, 2, 1, 1, -1000, 0, 2, -1000);
            Console.WriteLine("Risk: {0:f}%", risk);
            Console.WriteLine();
            Console.WriteLine("The following assessment is a percentage value of risk of contracting melanoma" +
                              " for a non-hispanic white female of 40 in south US, with dark skin complexion," +
                              " deep brown tanning, 12 or more moles less than or equal tp 5mm in size, " +
                              " and severe freckling on the back skin tissue." + Environment.NewLine);
            risk = Calculate.CalculateRisk(2, 2, 1, 40, -1000, 3, -1000, -1000, 3, 3, -1000, 1);
            Console.WriteLine("Risk: {0:f}%", risk);
            Console.WriteLine();
        }
    }
}
